﻿using System;
using MonsterTradingCardsGame;
using MonsterTradingCardsGame.Server;
using Npgsql;

await new Server().Start();