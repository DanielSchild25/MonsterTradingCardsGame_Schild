﻿using System;
using MonsterTradingCardsGame.Server;
using Npgsql;

await new Server().Start();